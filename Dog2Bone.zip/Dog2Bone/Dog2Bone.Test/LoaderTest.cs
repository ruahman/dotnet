﻿using System.IO;
using Xunit;
using Xunit.Abstractions;
using System;
using Dog2Bone.Engine;


namespace Dog2Bone.Test
{
    using Dog2Bone.Loader;

    public class LoaderTest
    {
        private readonly ITestOutputHelper _testOut;

        public LoaderTest(ITestOutputHelper testOutputHelper)
        {
            _testOut = testOutputHelper;

        }

        [Fact]
        public void Loader_ReturnsGameEngine()
        {
            Loader.Logger = _testOut;

            var gameEngine = Loader.LoadDogToBone(
                @"fixtures/initialize/initialize0.json",
                @"fixtures/moves/moves0.csv");

            Assert.NotNull(gameEngine);

            Assert.Equal(5, gameEngine.Board.Item1);
            Assert.Equal(4, gameEngine.Board.Item2);

            Assert.Equal(0, gameEngine.Dog.Position.X);
            Assert.Equal(2, gameEngine.Dog.Position.Y);
            Assert.Equal(Moves.North, gameEngine.Dog.Direction);

            Assert.Equal(4, gameEngine.Bone.Item1);
            Assert.Equal(1, gameEngine.Bone.Item2);

            Assert.Equal(3, gameEngine.Cats.Count);

            Assert.Equal(9, gameEngine.Moves.Count);

        }

        [Theory]
        [InlineData("initialize-success", null)]
        [InlineData("initialize-dogoutofbounds", typeof(DogOutOfBounds))]
        [InlineData("initialize-dogwakecat", typeof(DogWakeCat))]
        [InlineData("initialize-dogfoundbone", typeof(DogFoundBone))]
        [InlineData("initialize-catoutofbounds", typeof(CatOutOfBounds))]
        [InlineData("initialize-catfoundbone", typeof(CatFoundBone))]
        [InlineData("initialize-boneoutofbounds", typeof(BoneOutOfBounds))]
        public void Loader_GetsInititalizationFile_ThrowsExeption_IfInvalid(string initFile, Type exceptionType)
        {
            var initializePath = @$"fixtures/initialize/{initFile}.json";

            var movesPath = @"fixtures/moves/moves0.csv";

            if (exceptionType == null)
            {
                var gameEngine = Loader.LoadDogToBone(initializePath, movesPath);
                Assert.NotNull(gameEngine);
            }
            else
            {
                GameEngine gameEngine = null;
                var ex = Assert.ThrowsAny<GameEngineException>(() =>
                {
                    gameEngine = Loader.LoadDogToBone(initializePath, movesPath);
                });

                Assert.Equal(ex.GetType(), exceptionType);

                Assert.Null(gameEngine);
            }
        }

        [Fact]
        public void Loader_ValidatesMovesFile()
        {
            GameEngine gameEngine = null;
            var ex = Assert.Throws<InvalidMove>(() =>
            {
                gameEngine = Loader.LoadDogToBone(
                    @"fixtures/initialize/initialize0.json",
                    @"fixtures/moves/moves-invalid.csv");
            });


            Assert.Null(gameEngine);
        }
    }
}
